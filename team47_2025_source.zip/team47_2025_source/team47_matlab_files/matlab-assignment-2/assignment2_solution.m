%% Assignment 2 - Velocity control of the cart

clear; close all; clc; 

%% Configuration
Ts = 0.01;
dataDir = '/Users/tiebertlefebure/Documents/Master of Mechanical Engineering/Control Theory/Arduino/matlab_assign2/data';
scriptDir = fileparts(mfilename('fullpath'));
if isempty(scriptDir)
    scriptDir = pwd;
end
projectRoot = fileparts(scriptDir);
texImageDir = fullfile(projectRoot, 'tex_control', 'ass2_tex', 'images');
if ~exist(texImageDir, 'dir')
    mkdir(texImageDir);
end

%% Motor models from Assignment 1 (simplified 2nd-order model)
% H(z) = b1 / (z^2 + a1*z)  =>  tf([b1], [1, a1, 0], Ts)
wheelA_tf = tf([0.6309], [1, -0.6819, 0], Ts); % DT transfer function (simplified model, filtered) - Wheel A
wheelB_tf = tf([0.6488], [1, -0.6806, 0], Ts); % DT transfer function (simplified model, filtered) - Wheel B

% Convert to continuous-time for controller design
wheelA_cont = d2c(wheelA_tf, 'tustin'); % CT transfer function (simplified model, filtered) - Wheel A
wheelB_cont = d2c(wheelB_tf, 'tustin'); % CT transfer function (simplified model, filtered) - Wheel B



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SECTION 1(b) - CONTROLLER DESIGN PROCESS AND DESIGN PARAMETERS CHOICES 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Step 1: Bode plot of G(s) - Wheel A (determine w_c where phase = -110 deg (for 55 deg PM) )
fig = new_fig();
bode(wheelA_cont);
hold on;
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    if contains(ax(i).YLabel.String, 'Phase')
        axes(ax(i)); hold on;
        yline(-110, 'r--', '\phi = -110 deg (target for 55 deg PM)', 'LabelHorizontalAlignment', 'left');
    end
end
title('Uncompensated open-loop system G_s(s) - Wheel A');
grid on;
save_plot(fig, texImageDir, 'bode_uncompensated_motorA');
%close(fig);

%% Bode plot of G(s) - Wheel B

fig = new_fig();
bode(wheelB_cont);
hold on;
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    if contains(ax(i).YLabel.String, 'Phase')
        axes(ax(i)); hold on;
        yline(-110, 'r--', '\phi = -110 deg (target for 55 deg PM)', 'LabelHorizontalAlignment', 'left');
    end
end
title('Uncompensated open-loop system G_s(s) - Wheel B');
grid on;
save_plot(fig, texImageDir, 'bode_uncompensated_motorB');
%close(fig);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  NOMINAL CONTROLLER (high bandwidth, 61.7 rad/s crossover)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
%%% DETERMINE TARGET CROSS-OVER FREQUENCY %%%
wc_nom = 61.7;  % target cross-over frequency - Wheel A  % target cross-over frequency - Wheel B
Ti_nom = tand(90 - 15) / wc_nom      % integrator time constant (15 deg lag reserve)

% Compute gain K so that |L(j*wc)| = 1
D_nom = tf([Ti_nom 1], [Ti_nom 0]); % CT PI compensator without gain K (same structure for both wheels)

L_base_nom_A = D_nom * wheelA_cont; % CT compensated system without gain K (K=1) - Wheel A
%L_base_nom_A = 0.8904*D_nom * wheelA_cont; % CT compensated system wit gain K = 0.8904 - Wheel A

L_base_nom_B = D_nom * wheelB_cont; % CT compensated system without gain K (K=1) - Wheel B
%L_base_nom_B = 0.8663*D_nom * wheelB_cont; % CT compensated system with gain K = 0.8663 - Wheel B


K_nom_A = 1 / abs(evalfr(L_base_nom_A, 1i * wc_nom)); % proportional gain K - Wheel A
K_nom_B = 1 / abs(evalfr(L_base_nom_B, 1i * wc_nom)); % proportional gain K - Wheel B

% Continuous and discrete PI controller
C_nom_cont_A = tf([K_nom_A, K_nom_A / Ti_nom], [1, 0]); % CT PI compensator with gain K = 0.8904 - Wheel A
C_nom_disc_A = c2d(C_nom_cont_A, Ts, 'tustin'); % DT PI compensator with gain K = 0.8904 - Wheel A

C_nom_cont_B = tf([K_nom_B, K_nom_B / Ti_nom], [1, 0]); % CT PI compensator with gain K = 0.8663 - Wheel B
C_nom_disc_B = c2d(C_nom_cont_B, Ts, 'tustin'); % DT PI compensator with gain K = 0.8663 - Wheel B

% Open-loop, closed-loop, sensitivity, control TF (Wheel A/B for simulation)
L_nom_A = C_nom_disc_A * wheelA_tf; % DT open-loop compensated system (full compensator) - Wheel A
T_nom_A = feedback(L_nom_A, 1) % DT closed-loop compensated system - Wheel A
S_nom_A = feedback(1, L_nom_A); % Sensitivity TF
U_nom_A = feedback(C_nom_disc_A, wheelA_tf); % Control effort TF

L_nom_B = C_nom_disc_B * wheelB_tf; % DT open-loop compensated system (full compensator) - Wheel B
T_nom_B = feedback(L_nom_B, 1) % DT closed-loop compensated system - Wheel B
S_nom_B = feedback(1, L_nom_B); % Sensitivity TF
U_nom_B = feedback(C_nom_disc_B, wheelB_tf); % Control effort TF

[num_nom_A, den_nom_A] = tfdata(C_nom_disc_A, 'v');

[num_nom_B, den_nom_B] = tfdata(C_nom_disc_B, 'v');

%% CT open-loop compensated systel without gain K - Wheel A ---> determine proportional gain K

% Step 2: Bode plot of D(s)*G(s) with K=1 - determine gain K where |D*G| = 1 at w_c
fig = new_fig();
bode(L_base_nom_A);
hold on;
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    if contains(ax(i).YLabel.String, 'Magnitude')
        axes(ax(i)); hold on;
        yline(0, 'r--', '0 dB (|D*G| = 1)', 'LabelHorizontalAlignment', 'left');
        xline(wc_nom, 'b--', sprintf('\\omega_c = %.1f rad/s', wc_nom), 'LabelOrientation', 'horizontal');
    end
end
title('Compensated open-loop system D(s)*G_s(s) with gain K = 1 - Wheel A');
%title('Compensated open-loop system D(s)*G_s(s) with gain K = 0.8904 - Wheel A');
grid on;
save_plot(fig, texImageDir, 'bode_compensated_nominal_motorA');
%close(fig);
%% CT open-loop compensated system without gain K - Wheel B

% Step 2: Bode plot of D(s)*G(s) with K=1 - wheel B - determine gain K where |D*G| = 1 at w_c
fig = new_fig();
bode(L_base_nom_B);
hold on;
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    if contains(ax(i).YLabel.String, 'Magnitude')
        axes(ax(i)); hold on;
        yline(0, 'r--', '0 dB (|D*G| = 1)', 'LabelHorizontalAlignment', 'left');
        xline(wc_nom, 'b--', sprintf('\\omega_c = %.1f rad/s', wc_nom), 'LabelOrientation', 'horizontal');
    end
end
title('Compensated open-loop system D(s)*G_s(s) with gain K = 1 - Wheel B');
grid on;
save_plot(fig, texImageDir, 'bode_compensated_nominal_motorB');
%close(fig);



%% Frequency-domain verification: DT open-loop compensated system D(jw)Gs(jw) - Wheel A

% Step 3: Open-loop Bode L = G_c * G_s with annotated design parameters (Section 1b)
fig = new_fig();
[mag_nom, phase_nom, w_nom] = bode(L_nom_A);
margin(L_nom_A);
hold on;
title('Compensated open-loop system L(s) = D(s)*G_s(s) - Wheel A');
[Gm_nom, Pm_nom, Wcg_nom, Wcp_nom] = margin(L_nom_A);
%title(sprintf('Compensated open-loop system L(s) = G_c(s)*G_s(s) - Wheel A');

% Add crossover frequency annotation
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    if contains(ax(i).YLabel.String, 'Magnitude')
        axes(ax(i)); hold on;
        xline(Wcp_nom, 'r--', sprintf('\\omega_c = %.1f rad/s', Wcp_nom), 'LabelOrientation', 'horizontal', 'LabelVerticalAlignment', 'bottom');
    elseif contains(ax(i).YLabel.String, 'Phase')
        axes(ax(i)); hold on;
        yline(-180 + Pm_nom, 'r--', sprintf('PM = %.1f deg', Pm_nom), 'LabelHorizontalAlignment', 'left');
    end
end
save_plot(fig, texImageDir, 'open_loop_bode_motorA');
%close(fig);


%% Frequency-domain verification: DT open-loop compensated system D(jw)Gs(jw) - Wheel B

fig = new_fig();
[mag_nom, phase_nom, w_nom] = bode(L_nom_B);
margin(L_nom_B);
hold on;
title('Compensated open-loop system L(s) = D(s)*G_s(s) - Wheel B');
[~, Pm_nom_B, ~, Wcp_nom_B] = margin(L_nom_B);
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    if contains(ax(i).YLabel.String, 'Magnitude')
        axes(ax(i)); hold on;
        xline(Wcp_nom_B, 'r--', sprintf('\\omega_c = %.1f rad/s', Wcp_nom_B), 'LabelOrientation', 'horizontal', 'LabelVerticalAlignment', 'bottom');
    elseif contains(ax(i).YLabel.String, 'Phase')
        axes(ax(i)); hold on;
        yline(-180 + Pm_nom_B, 'r--', sprintf('PM = %.1f deg', Pm_nom_B), 'LabelHorizontalAlignment', 'left');
    end
end
save_plot(fig, texImageDir, 'open_loop_bode_motorB');
%close(fig);


%% Frequency-domain verification: DT closed-loop compensated system - Wheel A 

% Closed-loop Bode (nominal controller)
fig = new_fig();
bode(T_nom_A);
grid on;
title('Compensated closed-loop system H(s) = L(s) / [1+L(s)] - Wheel A');
save_plot(fig, texImageDir, 'closed_loop_bode_motorA');


% Time-domain verification (step response)
fig = new_fig();
step(T_nom_A);
grid on;
info_A = stepinfo(T_nom_A);
dc_A = dcgain(T_nom_A);
title(sprintf('Step response of H(s) - Wheel A\nt_r = %.3fs (< 0.5s), M_p = %.1f%% (< 20%%)', info_A.RiseTime, info_A.Overshoot));
save_plot(fig, texImageDir, 'step_response_verification_motorA');
%close(fig);

%% Frequency-domain verification: DT closed-loop compensated system - Wheel B

fig = new_fig();
bode(T_nom_B);
grid on;
title('Compensated closed-loop system H(s) - Wheel B');
save_plot(fig, texImageDir, 'closed_loop_bode_motorB');


% Time-domain verification (step response)
fig = new_fig();
step(T_nom_B);
grid on;
info_B = stepinfo(T_nom_B);
dc_B = dcgain(T_nom_B);
title(sprintf('Step response of H(s) - Wheel B\nt_r = %.3fs (< 0.5s), M_p = %.1f%% (< 20%%)', info_B.RiseTime, info_B.Overshoot));
save_plot(fig, texImageDir, 'step_response_verification_motorB');
%close(fig);

%% Frequency-domain verification: DT PI compensator - Wheel A

% Bode PI controller
fig = new_fig();
bode(C_nom_disc_A);
grid on;
title('PI compensator D(s) - Wheel A');

% Check PI zero requirement: w_z << w_c
w_z = 1/Ti_nom;

ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    axes(ax(i)); hold on;
    xline(w_z, 'g--', sprintf('\\omega_z = %.1f', w_z), 'LabelVerticalAlignment', 'bottom');
    xline(wc_nom, 'r--', sprintf('\\omega_c = %.1f', wc_nom), 'LabelVerticalAlignment', 'bottom');
end
save_plot(fig, texImageDir, 'PI_compensator_motorA');
%close(fig);


%% Frequency-domain verification: DT PI compensator - Wheel B

% Bode PI controller
fig = new_fig();
bode(C_nom_disc_B);
grid on;
title('PI compensator D(s) - Wheel B');

% Check PI zero requirement: w_z << w_c
w_z = 1/Ti_nom;

% Check PI zero requirement 
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    axes(ax(i)); hold on;
    xline(w_z, 'g--', sprintf('\\omega_z = %.1f', w_z), 'LabelVerticalAlignment', 'bottom');
    xline(wc_nom, 'r--', sprintf('\\omega_c = %.1f', wc_nom), 'LabelVerticalAlignment', 'bottom');
end
save_plot(fig, texImageDir, 'PI_compensator_motorB');
%close(fig);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  LOW-BANDWIDTH CONTROLLER (0.5 Hz = 3.14 rad/s crossover)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

wc_low = 2 * pi * 0.5;                % ~3.14 rad/s
Ti_low = tand(90 - 15) / wc_low;

D_low = tf([Ti_low 1], [Ti_low 0]); % PI compensator without gain K (same structure for both wheels)

L_base_low_A = D_low * wheelA_cont; % CT compensated system without gain K - Wheel A
L_base_low_B = D_low * wheelB_cont; % CT compensated system without gain K - Wheel B

K_low_A = 1 / abs(evalfr(L_base_low_A, 1i * wc_low)); % proportional gain K - Wheel A
K_low_B = 1 / abs(evalfr(L_base_low_B, 1i * wc_low)); % proportional gain K - Wheel B

% Continuous and discrete PI controller
C_low_cont_A = tf([K_low_A, K_low_A / Ti_low], [1, 0]); % CT PI compensator with gain K - Wheel A
C_low_disc_A = c2d(C_low_cont_A, Ts, 'tustin'); % DT PI compensator with gain K - Wheel A

C_low_cont_B = tf([K_low_B, K_low_B / Ti_low], [1, 0]); % CT PI compensator with gain K - Wheel B
C_low_disc_B = c2d(C_low_cont_B, Ts, 'tustin'); % DT PI compensator with gain K - Wheel B

% Open-loop, closed-loop, sensitivity, control TF (Wheel A/B for simulation)
L_low_A = C_low_disc_A * wheelA_tf; % DT open-loop compensated system - Wheel A
T_low_A = feedback(L_low_A, 1); % DT closed-loop compensated system
S_low_A = feedback(1, L_low_A); % Sensitivity TF
U_low_A = feedback(C_low_disc_A, wheelA_tf); % Control effort TF

L_low_B = C_low_disc_B * wheelB_tf; % DT open-loop compensated system - Wheel B
T_low_B = feedback(L_low_B, 1); % DT closed-loop compensated system
S_low_B = feedback(1, L_low_B); % Sensitivity TF
U_low_B = feedback(C_low_disc_B, wheelB_tf); % Control effort TF

[num_low_A, den_low_A] = tfdata(C_low_disc_A, 'v');

[num_low_B, den_low_B] = tfdata(C_low_disc_B, 'v');

% Step 2 (Low-BW): Bode plot of D(s)*G(s) with K=1 - determine gain K
fig = new_fig();
bode(L_base_low_A);
hold on;
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    if contains(ax(i).YLabel.String, 'Magnitude')
        axes(ax(i)); hold on;
        yline(0, 'r--', '0 dB (|D*G| = 1)', 'LabelHorizontalAlignment', 'left');
        xline(wc_low, 'b--', sprintf('\\omega_c = %.1f rad/s', wc_low), 'LabelOrientation', 'horizontal');
    end
end
title(sprintf('Low-BW: Open-loop L(s) = D(s)*G(s) with K=1 - Wheel A - Read gain at \\omega_c = %.1f rad/s', wc_low));
grid on;
save_plot(fig, texImageDir, 'bode_compensated_lowband_motorA');
%close(fig);

% Step 3 (Low-BW): Open-loop Bode L = G_c * G_s - verify PM
fig = new_fig();
margin(L_low_A);
hold on;
[~, Pm_low, ~, Wcp_low] = margin(L_low_A);
title(sprintf('Low-BW: Open-loop L(s)  - Wheel A - Verify PM = %.1f deg at \\omega_c = %.1f rad/s', Pm_low, Wcp_low));
% Add crossover frequency annotation
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    if contains(ax(i).YLabel.String, 'Magnitude')
        axes(ax(i)); hold on;
        xline(Wcp_low, 'r--', sprintf('\\omega_c = %.1f rad/s', Wcp_low), 'LabelOrientation', 'horizontal', 'LabelVerticalAlignment', 'bottom');
    elseif contains(ax(i).YLabel.String, 'Phase')
        axes(ax(i)); hold on;
        yline(-180 + Pm_low, 'r--', sprintf('PM = %.1f deg', Pm_low), 'LabelHorizontalAlignment', 'left');
    end
end
save_plot(fig, texImageDir, 'open_loop_bode_lowband_motorA');
%close(fig);

fig = new_fig();
margin(L_low_B);
hold on;
[~, Pm_low_B, ~, Wcp_low_B] = margin(L_low_B);
title(sprintf('Low-BW: Open-loop L(s)  - Wheel B - Verify PM = %.1f deg at \\omega_c = %.1f rad/s', Pm_low_B, Wcp_low_B));
ax = findall(fig, 'Type', 'axes');
for i = 1:length(ax)
    if contains(ax(i).YLabel.String, 'Magnitude')
        axes(ax(i)); hold on;
        xline(Wcp_low_B, 'r--', sprintf('\\omega_c = %.1f rad/s', Wcp_low_B), 'LabelOrientation', 'horizontal', 'LabelVerticalAlignment', 'bottom');
    elseif contains(ax(i).YLabel.String, 'Phase')
        axes(ax(i)); hold on;
        yline(-180 + Pm_low_B, 'r--', sprintf('PM = %.1f deg', Pm_low_B), 'LabelHorizontalAlignment', 'left');
    end
end
save_plot(fig, texImageDir, 'open_loop_bode_lowband_motorB');
%close(fig);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SECTION 2(a) - FLAT GROUND STEP RESPONSE VALIDATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

csvfile_flat = fullfile(dataDir, 'cart_flat_step3.csv');
if isfile(csvfile_flat)
    raw_flat = readmatrix(csvfile_flat, 'NumHeaderLines', 2);
    raw_flat = raw_flat(125:425, :);  % Clip to relevant range
    t_flat = 0:Ts:3; %(raw_flat(:,1) - raw_flat(1,1)) * 1e-3;
    ref_flat = raw_flat(:, 2);
    speedA_flat = raw_flat(:, 3);
    speedB_flat = raw_flat(:, 4);
    errorA_flat = raw_flat(:, 5);
    errorB_flat = raw_flat(:, 6);
    ctrlA_flat = raw_flat(:, 7);
    ctrlB_flat = raw_flat(:, 8);

    sim_flat_A = lsim(T_nom_A, ref_flat, t_flat);
    sim_flat_B = lsim(T_nom_B, ref_flat, t_flat);
    sim_err_flat_A = lsim(S_nom_A, ref_flat, t_flat);
    sim_err_flat_B = lsim(S_nom_B, ref_flat, t_flat);
    sim_ctrl_flat_A = lsim(U_nom_A, ref_flat, t_flat);
    sim_ctrl_flat_B = lsim(U_nom_B, ref_flat, t_flat);

    % Wheel A
    fig = new_fig();
    plot(t_flat, ref_flat, 'k:', 'LineWidth', 1.5); hold on;
    plot(t_flat, speedA_flat, 'k-', 'LineWidth', 1.2);
    plot(t_flat, sim_flat_A, 'k--', 'LineWidth', 1.2);
    legend('Reference', 'Measured', 'Simulated', 'Location', 'southeast');
    title('Step response - Wheel A'); xlabel('Time [s]'); ylabel('Velocity [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'step_response_no_disturbance_motorA');
    %close(fig);

    fig = new_fig();
    plot(t_flat, errorA_flat, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_flat, sim_err_flat_A, 'k--', 'LineWidth', 1.2);
    legend('Measured', 'Simulated', 'Location', 'southeast');
    title('Tracking error - Wheel A'); xlabel('Time [s]'); ylabel('Error [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'tracking_error_no_disturbance_motorA');
    %close(fig);

    fig = new_fig();
    plot(t_flat, ctrlA_flat, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_flat, sim_ctrl_flat_A, 'k--', 'LineWidth', 1.2);
    legend('Measured', 'Simulated', 'Location', 'southeast');
    title('Control signal - Wheel A'); xlabel('Time [s]'); ylabel('Voltage [V]'); grid on;
    save_plot(fig, texImageDir, 'control_signal_no_disturbance_motorA');
    %close(fig);

    % Wheel B
    fig = new_fig();
    plot(t_flat, ref_flat, 'k:', 'LineWidth', 1.5); hold on;
    plot(t_flat, speedB_flat, 'k-', 'LineWidth', 1.2);
    plot(t_flat, sim_flat_B, 'k--', 'LineWidth', 1.2);
    legend('Reference', 'Measured', 'Simulated', 'Location', 'southeast');
    title('Step response - Wheel B'); xlabel('Time [s]'); ylabel('Velocity [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'step_response_no_disturbance_motorB');
    %close(fig);

    fig = new_fig();
    plot(t_flat, errorB_flat, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_flat, sim_err_flat_B, 'k--', 'LineWidth', 1.2);
    legend('Measured', 'Simulated', 'Location', 'southeast');
    title('Tracking error - Wheel B'); xlabel('Time [s]'); ylabel('Error [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'tracking_error_no_disturbance_motorB');
    %close(fig);

    fig = new_fig();
    plot(t_flat, ctrlB_flat, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_flat, sim_ctrl_flat_B, 'k--', 'LineWidth', 1.2);
    legend('Measured', 'Simulated', 'Location', 'southeast');
    title('Control signal - Wheel B'); xlabel('Time [s]'); ylabel('Voltage [V]'); grid on;
    save_plot(fig, texImageDir, 'control_signal_no_disturbance_motorB');
    %close(fig);
else
    fprintf('[INFO] Flat ground data not found: %s\n', csvfile_flat);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SECTION 2(b) - STEADY-STATE PERFORMANCE UNDER CONSTANT FORCE DISTURBANCE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

csvfile_incline = fullfile(dataDir, 'cart_incline_nominal.csv');
if isfile(csvfile_incline)
    raw_inc = readmatrix(csvfile_incline, 'NumHeaderLines', 2);
    raw_inc = raw_inc(71:371, :); 
    t_inc = 0:Ts:3; 
    ref_inc = raw_inc(:, 2);
    speedA_inc = raw_inc(:, 3);
    speedB_inc = raw_inc(:, 4);
    errorA_inc = raw_inc(:, 5);
    errorB_inc = raw_inc(:, 6);
    ctrlA_inc = raw_inc(:, 7);
    ctrlB_inc = raw_inc(:, 8);

    sim_inc_A = lsim(T_nom_A, ref_inc, t_inc);
    sim_inc_B = lsim(T_nom_B, ref_inc, t_inc);
    sim_err_inc_A = lsim(S_nom_A, ref_inc, t_inc);
    sim_err_inc_B = lsim(S_nom_B, ref_inc, t_inc);
    sim_ctrl_inc_A = lsim(U_nom_A, ref_inc, t_inc);
    sim_ctrl_inc_B = lsim(U_nom_B, ref_inc, t_inc);

    % Wheel A
    fig = new_fig();
    plot(t_inc, ref_inc, 'k:', 'LineWidth', 1.5); hold on;
    plot(t_inc, speedA_inc, 'k-', 'LineWidth', 1.2);
    plot(t_inc, sim_inc_A, 'k--', 'LineWidth', 1.2);
    legend('Reference', 'Measured', 'Simulated', 'Location', 'southeast');
    title('Step response with constant disturbance - Wheel A'); xlabel('Time [s]'); ylabel('Velocity [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'step_response_with_disturbance_motorA');
    %close(fig);

    fig = new_fig();
    plot(t_inc, errorA_inc, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_inc, sim_err_inc_A, 'k--', 'LineWidth', 1.2);
    legend('Measured', 'Simulated', 'Location', 'southeast');
    title('Tracking error with constant disturbance - Wheel A'); xlabel('Time [s]'); ylabel('Error [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'tracking_error_with_disturbance_motorA');
    %close(fig);

    fig = new_fig();
    plot(t_inc, ctrlA_inc, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_inc, sim_ctrl_inc_A, 'k--', 'LineWidth', 1.2);
    legend('Measured', 'Simulated', 'Location', 'southeast');
    title('Control signal with constant disturbance - Wheel A'); xlabel('Time [s]'); ylabel('Voltage [V]'); grid on;
    save_plot(fig, texImageDir, 'control_signal_with_disturbance_motorA');
    %close(fig);

    % Wheel B
    fig = new_fig();
    plot(t_inc, ref_inc, 'k:', 'LineWidth', 1.5); hold on;
    plot(t_inc, speedB_inc, 'k-', 'LineWidth', 1.2);
    plot(t_inc, sim_inc_B, 'k--', 'LineWidth', 1.2);
    legend('Reference', 'Measured', 'Simulated', 'Location', 'southeast');
    title('Step response with constant disturbance - Wheel B'); xlabel('Time [s]'); ylabel('Velocity [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'step_response_with_disturbance_motorB');
    %close(fig);

    fig = new_fig();
    plot(t_inc, errorB_inc, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_inc, sim_err_inc_B, 'k--', 'LineWidth', 1.2);
    legend('Measured', 'Simulated', 'Location', 'southeast');
    title('Tracking error with constant disturbance - Wheel B'); xlabel('Time [s]'); ylabel('Error [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'tracking_error_with_disturbance_motorB');
    %close(fig);

    fig = new_fig();
    plot(t_inc, ctrlB_inc, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_inc, sim_ctrl_inc_B, 'k--', 'LineWidth', 1.2);
    legend('Measured', 'Simulated', 'Location', 'southeast');
    title('Control signal with constant disturbance - Wheel B'); xlabel('Time [s]'); ylabel('Voltage [V]'); grid on;
    save_plot(fig, texImageDir, 'control_signal_with_disturbance_motorB');
    %close(fig);
else
    fprintf('[INFO] Incline nominal data not found: %s\n', csvfile_incline);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SECTION 2(c) -  LOW-BANDWIDTH CONTROLLER VALIDATION UNDER CONSTANT FORCE DISTURBANCE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

csvfile_incline_low = fullfile(dataDir, 'cart_incline_lowband.csv');
if isfile(csvfile_incline) && isfile(csvfile_incline_low)
    raw_low = readmatrix(csvfile_incline_low, 'NumHeaderLines', 2);
    raw_low = raw_low(331:631, :);  
    t_low = 0:Ts:3; 
    ref_low = raw_low(:, 2);
    speedA_low = raw_low(:, 3);
    speedB_low = raw_low(:, 4);
    errorA_low = raw_low(:, 5);
    errorB_low = raw_low(:, 6);
    ctrlA_low = raw_low(:, 7);
    ctrlB_low = raw_low(:, 8);

    sim_inc_nom_A = lsim(T_nom_A, ref_inc, t_inc);
    sim_inc_nom_B = lsim(T_nom_B, ref_inc, t_inc);
    sim_inc_low_A = lsim(T_low_A, ref_low, t_low);
    sim_inc_low_B = lsim(T_low_B, ref_low, t_low);
    sim_err_nom_A = lsim(S_nom_A, ref_inc, t_inc);
    sim_err_nom_B = lsim(S_nom_B, ref_inc, t_inc);
    sim_err_low_A = lsim(S_low_A, ref_low, t_low);
    sim_err_low_B = lsim(S_low_B, ref_low, t_low);
    sim_ctrl_nom_A = lsim(U_nom_A, ref_inc, t_inc);
    sim_ctrl_nom_B = lsim(U_nom_B, ref_inc, t_inc);
    sim_ctrl_low_A = lsim(U_low_A, ref_low, t_low);
    sim_ctrl_low_B = lsim(U_low_B, ref_low, t_low);

    % Wheel A - closed-loop comparison
    fig = new_fig();
    plot(t_inc, ref_inc, 'k:', 'LineWidth', 0.7); hold on;
    plot(t_inc, speedA_inc, 'k-', 'LineWidth', 1.2);
    plot(t_low, speedA_low, 'k-.', 'LineWidth', 1.2);
    plot(t_inc, sim_inc_nom_A, 'k--', 'LineWidth', 1);
    plot(t_low, sim_inc_low_A, 'k:', 'LineWidth', 1.5);
    legend('Reference', 'Nominal (meas)', 'Low-BW (meas)', 'Nominal (sim)', 'Low-BW (sim)', 'Location', 'southeast');
    title('Step response with low-bandwidth (and constant disturbance) - Wheel A'); xlabel('Time [s]'); ylabel('Velocity [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'step_response_high_vs_low_BW_motorA');
    %close(fig);

    % Wheel A - tracking error comparison
    fig = new_fig();
    plot(t_inc, errorA_inc, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_low, errorA_low, 'k-.', 'LineWidth', 1.2);
    plot(t_inc, sim_err_nom_A, 'k--', 'LineWidth', 1);
    plot(t_low, sim_err_low_A, 'k:', 'LineWidth', 1.5);
    legend('Nominal (meas)', 'Low-BW (meas)', 'Nominal (sim)', 'Low-BW (sim)', 'Location', 'southeast');
    title('Tracking error with low-bandwidth (and constant disturbance) - Wheel A'); xlabel('Time [s]'); ylabel('Error [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'tracking_error_high_vs_low_BW_motorA');
    %close(fig);

    % Wheel A - control signal comparison
    fig = new_fig();
    plot(t_inc, ctrlA_inc, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_low, ctrlA_low, 'k-.', 'LineWidth', 1.2);
    plot(t_inc, sim_ctrl_nom_A, 'k--', 'LineWidth', 1);
    plot(t_low, sim_ctrl_low_A, 'k:', 'LineWidth', 1.5);
    legend('Nominal (meas)', 'Low-BW (meas)', 'Nominal (sim)', 'Low-BW (sim)', 'Location', 'southeast');
    title('Control signal with low-bandwidth (and constant disturbance) - Wheel A'); xlabel('Time [s]'); ylabel('Voltage [V]'); grid on;
    save_plot(fig, texImageDir, 'control_signal_high_vs_low_BW_motorA');
    %close(fig);

    % Wheel B - closed-loop comparison
    fig = new_fig();
    plot(t_inc, ref_inc, 'k:', 'LineWidth', 0.7); hold on;
    plot(t_inc, speedB_inc, 'k-', 'LineWidth', 1.2);
    plot(t_low, speedB_low, 'k-.', 'LineWidth', 1.2);
    plot(t_inc, sim_inc_nom_B, 'k--', 'LineWidth', 1);
    plot(t_low, sim_inc_low_B, 'k:', 'LineWidth', 1.5);
    legend('Reference', 'Nominal (meas)', 'Low-BW (meas)', 'Nominal (sim)', 'Low-BW (sim)', 'Location', 'southeast');
    title('Step response with low-bandwidth (and constant disturbance) - Wheel B'); xlabel('Time [s]'); ylabel('Velocity [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'step_response_high_vs_low_BW_motorB');
    %close(fig);

    % Wheel B - tracking error comparison
    fig = new_fig();
    plot(t_inc, errorB_inc, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_low, errorB_low, 'k-.', 'LineWidth', 1.2);
    plot(t_inc, sim_err_nom_B, 'k--', 'LineWidth', 1);
    plot(t_low, sim_err_low_B, 'k:', 'LineWidth', 1.5);
    legend('Nominal (meas)', 'Low-BW (meas)', 'Nominal (sim)', 'Low-BW (sim)', 'Location', 'southeast');
    title('Tracking error with low-bandwidth (and constant disturbance) - Wheel B'); xlabel('Time [s]'); ylabel('Error [rad/s]'); grid on;
    save_plot(fig, texImageDir, 'tracking_error_high_vs_low_BW_motorB');
    %close(fig);

    % Wheel B - control signal comparison
    fig = new_fig();
    plot(t_inc, ctrlB_inc, 'k-', 'LineWidth', 1.2); hold on;
    plot(t_low, ctrlB_low, 'k-.', 'LineWidth', 1.2);
    plot(t_inc, sim_ctrl_nom_B, 'k--', 'LineWidth', 1);
    plot(t_low, sim_ctrl_low_B, 'k:', 'LineWidth', 1.5);
    legend('Nominal (meas)', 'Low-BW (meas)', 'Nominal (sim)', 'Low-BW (sim)', 'Location', 'southeast');
    title('Control signal with low-bandwidth (and constant disturbance) - Wheel B'); xlabel('Time [s]'); ylabel('Voltage [V]'); grid on;
    save_plot(fig, texImageDir, 'control_signal_high_vs_low_BW_motorB');
    %close(fig);
else
    fprintf('[INFO] Missing data for incline comparison (section 2c).\n');
end

fprintf('Done.\n');

function fig = new_fig()
fig = figure('Visible', 'on', 'Color', 'w');
drawnow;
end

function save_plot(figHandle, outDir, baseName)
if ~exist(outDir, 'dir')
    mkdir(outDir);
end
if ~ishandle(figHandle)
    figHandle = get(groot, 'CurrentFigure');
end
if ~ishandle(figHandle)
    error('No valid figure available for export.');
end
set(figHandle, 'PaperPositionMode', 'auto');
outfile = fullfile(outDir, [baseName '.pdf']);
set(figHandle, 'InvertHardcopy', 'off');
print(figHandle, outfile, '-dpdf', '-painters', '-bestfit');
end
