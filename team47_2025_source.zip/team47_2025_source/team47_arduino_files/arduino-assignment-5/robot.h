#ifndef ROBOT_H
#define ROBOT_H

/*
 * ROBOT Class
 *
 * Class incorporating the robot. This class is used to define state machines,
 * control algorithms, sensor readings,...
 * It should be interfaced with the communicator to send data to the world.
 *
 */

#include "mecotron.h" 
#include <BasicLinearAlgebra.h> 
#include "extended_kalman_filter.h" 
using namespace BLA;

#define SWIVEL
#include <trajectory.h> 

class Robot : public MECOtron {
  private:

    Trajectory trajectory; 
    struct PiCoeffs {
      float b0;
      float b1;
      float feedback;
    };

    struct PiState {
      float errorPrev;
      float controlPrev;
    };

    // Kalman filter
    Matrix<3> _xhat;       // state estimate vector
    Matrix<3,3> _Phat;     // state estimate covariance
    Matrix<2> _nu;         // innovation vector
    Matrix<2,2> _S;        // innovation covariance

    // feedforward velocity commands for the cart
    Matrix<2> desiredVelocityCart;

    Matrix<2,3> _Klqr;        
    Matrix<3> _errorBody;     

    PiState piStateA;
    PiState piStateB;
    PiCoeffs piCoeffsA;
    PiCoeffs piCoeffsB;
    float kVoltageLimit = 11.0f;
    float kVelRefLimit = 12.0f;  

  public:
    Robot() { }

    void control();

    bool init();  

    bool controlEnabled();
    bool KalmanFilterEnabled();

    void resetController();
    void resetKalmanFilter();
    void resetVelocityController();
    void resetLqrController();

    void computeBodyFrameError(float x_ref, float y_ref, float theta_ref,
                               float x_hat, float y_hat, float theta_hat,
                               Matrix<3> &e_body);

    void button0callback();
    void button1callback();
    void button2callback();
    void button3callback();

    float saturate(float value, float limit) const;
    float applyPi(float error, PiState &state, const PiCoeffs &coeffs) const;

};

#endif // ROBOT_H
